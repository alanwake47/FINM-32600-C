//
// Created by Aman Krishna on 26/02/23.
//

#ifndef HW5_BOXMULLER_H
#define HW5_BOXMULLER_H

double BoxMuller();

#endif //HW5_BOXMULLER_H
