float get_rate(int currency);
float calc_forex(float base, float rate_b, float rate_f);