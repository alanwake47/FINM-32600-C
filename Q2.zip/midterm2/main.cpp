#include "nearest_prime.h"


int main() {
    int num;
    //test for n = 11
    num = 11;
    printFooBar(nearestPrime(num));
    //test for n = 23
    num = 23;
    printFooBar(nearestPrime(num));
    //test for n = 28
    num = 28;
    printFooBar(nearestPrime(num));
}
