//
// Created by Aman Krishna on 03/02/23.
//

#ifndef MIDTERM2_NEAREST_PRIME_H
#define MIDTERM2_NEAREST_PRIME_H

int nearestPrime(int num);
void printFooBar(int num);

#endif //MIDTERM2_NEAREST_PRIME_H
